import os

REPO_PATH = os.path.dirname(os.path.abspath(__file__))
RESOURCES_FOLDER = os.path.join(REPO_PATH, 'resources')
