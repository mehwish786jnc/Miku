import os


HF_TOKEN = os.environ.get('HUGGINGFACE_TOKEN')
WANDB_AUTH_TOKEN = os.environ.get('WANDB_AUTH_TOKEN')
